/**
 */
package SelfDrivingCar;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Motor Controller</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link SelfDrivingCar.MotorController#getMotorTemperature <em>Motor Temperature</em>}</li>
 * </ul>
 *
 * @see SelfDrivingCar.SelfDrivingCarPackage#getMotorController()
 * @model
 * @generated
 */
public interface MotorController extends EObject {
	/**
	 * Returns the value of the '<em><b>Motor Temperature</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Motor Temperature</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Motor Temperature</em>' attribute.
	 * @see #setMotorTemperature(float)
	 * @see SelfDrivingCar.SelfDrivingCarPackage#getMotorController_MotorTemperature()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	float getMotorTemperature();

	/**
	 * Sets the value of the '{@link SelfDrivingCar.MotorController#getMotorTemperature <em>Motor Temperature</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Motor Temperature</em>' attribute.
	 * @see #getMotorTemperature()
	 * @generated
	 */
	void setMotorTemperature(float value);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model speedRequired="true" speedOrdered="false"
	 * @generated
	 */
	void setSpeed(float speed);

} // MotorController
