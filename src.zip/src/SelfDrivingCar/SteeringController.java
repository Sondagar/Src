/**
 */
package SelfDrivingCar;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Steering Controller</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link SelfDrivingCar.SteeringController#getSteeringMode <em>Steering Mode</em>}</li>
 * </ul>
 *
 * @see SelfDrivingCar.SelfDrivingCarPackage#getSteeringController()
 * @model
 * @generated
 */
public interface SteeringController extends EObject {
	/**
	 * Returns the value of the '<em><b>Steering Mode</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Steering Mode</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Steering Mode</em>' attribute.
	 * @see #setSteeringMode(String)
	 * @see SelfDrivingCar.SelfDrivingCarPackage#getSteeringController_SteeringMode()
	 * @model dataType="org.eclipse.uml2.types.String" required="true" ordered="false"
	 * @generated
	 */
	String getSteeringMode();

	/**
	 * Sets the value of the '{@link SelfDrivingCar.SteeringController#getSteeringMode <em>Steering Mode</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Steering Mode</em>' attribute.
	 * @see #getSteeringMode()
	 * @generated
	 */
	void setSteeringMode(String value);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model angleRequired="true" angleOrdered="false"
	 * @generated
	 */
	void setSteeringAngle(float angle);

} // SteeringController
