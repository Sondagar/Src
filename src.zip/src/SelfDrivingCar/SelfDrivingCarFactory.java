/**
 */
package SelfDrivingCar;

import org.eclipse.emf.ecore.EFactory;

/**
 * <!-- begin-user-doc -->
 * The <b>Factory</b> for the model.
 * It provides a create method for each non-abstract class of the model.
 * <!-- end-user-doc -->
 * @see SelfDrivingCar.SelfDrivingCarPackage
 * @generated
 */
public interface SelfDrivingCarFactory extends EFactory {
	/**
	 * The singleton instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	SelfDrivingCarFactory eINSTANCE = SelfDrivingCar.impl.SelfDrivingCarFactoryImpl.init();

	/**
	 * Returns a new object of class '<em>Self Driving Car</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Self Driving Car</em>'.
	 * @generated
	 */
	SelfDrivingCar createSelfDrivingCar();

	/**
	 * Returns a new object of class '<em>Location</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Location</em>'.
	 * @generated
	 */
	Location createLocation();

	/**
	 * Returns a new object of class '<em>Drive System</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Drive System</em>'.
	 * @generated
	 */
	DriveSystem createDriveSystem();

	/**
	 * Returns a new object of class '<em>Motor Controller</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Motor Controller</em>'.
	 * @generated
	 */
	MotorController createMotorController();

	/**
	 * Returns a new object of class '<em>Brake Controller</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Brake Controller</em>'.
	 * @generated
	 */
	BrakeController createBrakeController();

	/**
	 * Returns a new object of class '<em>Steering Controller</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Steering Controller</em>'.
	 * @generated
	 */
	SteeringController createSteeringController();

	/**
	 * Returns a new object of class '<em>Sensor</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Sensor</em>'.
	 * @generated
	 */
	Sensor createSensor();

	/**
	 * Returns a new object of class '<em>Sensor Data</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Sensor Data</em>'.
	 * @generated
	 */
	SensorData createSensorData();

	/**
	 * Returns a new object of class '<em>Camera Sensor</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Camera Sensor</em>'.
	 * @generated
	 */
	CameraSensor createCameraSensor();

	/**
	 * Returns a new object of class '<em>Lidar Sensor</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Lidar Sensor</em>'.
	 * @generated
	 */
	LidarSensor createLidarSensor();

	/**
	 * Returns a new object of class '<em>Navigation System</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Navigation System</em>'.
	 * @generated
	 */
	NavigationSystem createNavigationSystem();

	/**
	 * Returns a new object of class '<em>Control Unit</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Control Unit</em>'.
	 * @generated
	 */
	ControlUnit createControlUnit();

	/**
	 * Returns a new object of class '<em>Communication Module</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Communication Module</em>'.
	 * @generated
	 */
	CommunicationModule createCommunicationModule();

	/**
	 * Returns the package supported by this factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the package supported by this factory.
	 * @generated
	 */
	SelfDrivingCarPackage getSelfDrivingCarPackage();

} //SelfDrivingCarFactory
