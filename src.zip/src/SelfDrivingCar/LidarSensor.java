/**
 */
package SelfDrivingCar;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Lidar Sensor</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link SelfDrivingCar.LidarSensor#getLidarType <em>Lidar Type</em>}</li>
 * </ul>
 *
 * @see SelfDrivingCar.SelfDrivingCarPackage#getLidarSensor()
 * @model
 * @generated
 */
public interface LidarSensor extends EObject {
	/**
	 * Returns the value of the '<em><b>Lidar Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Lidar Type</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Lidar Type</em>' attribute.
	 * @see #setLidarType(String)
	 * @see SelfDrivingCar.SelfDrivingCarPackage#getLidarSensor_LidarType()
	 * @model dataType="org.eclipse.uml2.types.String" required="true" ordered="false"
	 * @generated
	 */
	String getLidarType();

	/**
	 * Sets the value of the '{@link SelfDrivingCar.LidarSensor#getLidarType <em>Lidar Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Lidar Type</em>' attribute.
	 * @see #getLidarType()
	 * @generated
	 */
	void setLidarType(String value);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void scanEnvironment();

} // LidarSensor
