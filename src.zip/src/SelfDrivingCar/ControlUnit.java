/**
 */
package SelfDrivingCar;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Control Unit</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link SelfDrivingCar.ControlUnit#getProcessingPower <em>Processing Power</em>}</li>
 * </ul>
 *
 * @see SelfDrivingCar.SelfDrivingCarPackage#getControlUnit()
 * @model
 * @generated
 */
public interface ControlUnit extends EObject {
	/**
	 * Returns the value of the '<em><b>Processing Power</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Processing Power</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Processing Power</em>' attribute.
	 * @see #setProcessingPower(float)
	 * @see SelfDrivingCar.SelfDrivingCarPackage#getControlUnit_ProcessingPower()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	float getProcessingPower();

	/**
	 * Sets the value of the '{@link SelfDrivingCar.ControlUnit#getProcessingPower <em>Processing Power</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Processing Power</em>' attribute.
	 * @see #getProcessingPower()
	 * @generated
	 */
	void setProcessingPower(float value);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void processInput();

} // ControlUnit
