/**
 */
package SelfDrivingCar;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Camera Sensor</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link SelfDrivingCar.CameraSensor#getCameraType <em>Camera Type</em>}</li>
 * </ul>
 *
 * @see SelfDrivingCar.SelfDrivingCarPackage#getCameraSensor()
 * @model
 * @generated
 */
public interface CameraSensor extends Sensor {
	/**
	 * Returns the value of the '<em><b>Camera Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Camera Type</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Camera Type</em>' attribute.
	 * @see #setCameraType(String)
	 * @see SelfDrivingCar.SelfDrivingCarPackage#getCameraSensor_CameraType()
	 * @model dataType="org.eclipse.uml2.types.String" required="true" ordered="false"
	 * @generated
	 */
	String getCameraType();

	/**
	 * Sets the value of the '{@link SelfDrivingCar.CameraSensor#getCameraType <em>Camera Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Camera Type</em>' attribute.
	 * @see #getCameraType()
	 * @generated
	 */
	void setCameraType(String value);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void captureImage();

} // CameraSensor
