/**
 */
package SelfDrivingCar;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Drive System</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link SelfDrivingCar.DriveSystem#getMotorController <em>Motor Controller</em>}</li>
 *   <li>{@link SelfDrivingCar.DriveSystem#getBrakeController <em>Brake Controller</em>}</li>
 *   <li>{@link SelfDrivingCar.DriveSystem#getSteeringController <em>Steering Controller</em>}</li>
 * </ul>
 *
 * @see SelfDrivingCar.SelfDrivingCarPackage#getDriveSystem()
 * @model
 * @generated
 */
public interface DriveSystem extends EObject {
	/**
	 * Returns the value of the '<em><b>Motor Controller</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Motor Controller</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Motor Controller</em>' reference.
	 * @see #setMotorController(MotorController)
	 * @see SelfDrivingCar.SelfDrivingCarPackage#getDriveSystem_MotorController()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	MotorController getMotorController();

	/**
	 * Sets the value of the '{@link SelfDrivingCar.DriveSystem#getMotorController <em>Motor Controller</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Motor Controller</em>' reference.
	 * @see #getMotorController()
	 * @generated
	 */
	void setMotorController(MotorController value);

	/**
	 * Returns the value of the '<em><b>Brake Controller</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Brake Controller</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Brake Controller</em>' reference.
	 * @see #setBrakeController(BrakeController)
	 * @see SelfDrivingCar.SelfDrivingCarPackage#getDriveSystem_BrakeController()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	BrakeController getBrakeController();

	/**
	 * Sets the value of the '{@link SelfDrivingCar.DriveSystem#getBrakeController <em>Brake Controller</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Brake Controller</em>' reference.
	 * @see #getBrakeController()
	 * @generated
	 */
	void setBrakeController(BrakeController value);

	/**
	 * Returns the value of the '<em><b>Steering Controller</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Steering Controller</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Steering Controller</em>' reference.
	 * @see #setSteeringController(SteeringController)
	 * @see SelfDrivingCar.SelfDrivingCarPackage#getDriveSystem_SteeringController()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	SteeringController getSteeringController();

	/**
	 * Sets the value of the '{@link SelfDrivingCar.DriveSystem#getSteeringController <em>Steering Controller</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Steering Controller</em>' reference.
	 * @see #getSteeringController()
	 * @generated
	 */
	void setSteeringController(SteeringController value);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model speedRequired="true" speedOrdered="false"
	 * @generated
	 */
	void accelerate(float speed);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void brake();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model angleRequired="true" angleOrdered="false"
	 * @generated
	 */
	void steer(float angle);

} // DriveSystem
