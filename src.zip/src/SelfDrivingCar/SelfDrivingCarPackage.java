/**
 */
package SelfDrivingCar;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EOperation;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see SelfDrivingCar.SelfDrivingCarFactory
 * @model kind="package"
 * @generated
 */
public interface SelfDrivingCarPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "SelfDrivingCar";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http:///SelfDrivingCar.ecore";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "SelfDrivingCar";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	SelfDrivingCarPackage eINSTANCE = SelfDrivingCar.impl.SelfDrivingCarPackageImpl.init();

	/**
	 * The meta object id for the '{@link SelfDrivingCar.impl.SelfDrivingCarImpl <em>Self Driving Car</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see SelfDrivingCar.impl.SelfDrivingCarImpl
	 * @see SelfDrivingCar.impl.SelfDrivingCarPackageImpl#getSelfDrivingCar()
	 * @generated
	 */
	int SELF_DRIVING_CAR = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SELF_DRIVING_CAR__NAME = 0;

	/**
	 * The number of structural features of the '<em>Self Driving Car</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SELF_DRIVING_CAR_FEATURE_COUNT = 1;

	/**
	 * The operation id for the '<em>Start</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SELF_DRIVING_CAR___START = 0;

	/**
	 * The operation id for the '<em>Stop</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SELF_DRIVING_CAR___STOP = 1;

	/**
	 * The operation id for the '<em>Navigate To</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SELF_DRIVING_CAR___NAVIGATE_TO__LOCATION = 2;

	/**
	 * The operation id for the '<em>Update Sensors</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SELF_DRIVING_CAR___UPDATE_SENSORS = 3;

	/**
	 * The operation id for the '<em>Process Sensor Data</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SELF_DRIVING_CAR___PROCESS_SENSOR_DATA = 4;

	/**
	 * The operation id for the '<em>Make Decision</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SELF_DRIVING_CAR___MAKE_DECISION = 5;

	/**
	 * The operation id for the '<em>Communicate With Central System</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SELF_DRIVING_CAR___COMMUNICATE_WITH_CENTRAL_SYSTEM = 6;

	/**
	 * The operation id for the '<em>Execute Drive Command</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SELF_DRIVING_CAR___EXECUTE_DRIVE_COMMAND = 7;

	/**
	 * The number of operations of the '<em>Self Driving Car</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SELF_DRIVING_CAR_OPERATION_COUNT = 8;

	/**
	 * The meta object id for the '{@link SelfDrivingCar.impl.LocationImpl <em>Location</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see SelfDrivingCar.impl.LocationImpl
	 * @see SelfDrivingCar.impl.SelfDrivingCarPackageImpl#getLocation()
	 * @generated
	 */
	int LOCATION = 1;

	/**
	 * The feature id for the '<em><b>Latitude</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LOCATION__LATITUDE = 0;

	/**
	 * The feature id for the '<em><b>Longitude</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LOCATION__LONGITUDE = 1;

	/**
	 * The number of structural features of the '<em>Location</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LOCATION_FEATURE_COUNT = 2;

	/**
	 * The operation id for the '<em>Get Details</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LOCATION___GET_DETAILS = 0;

	/**
	 * The number of operations of the '<em>Location</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LOCATION_OPERATION_COUNT = 1;

	/**
	 * The meta object id for the '{@link SelfDrivingCar.impl.DriveSystemImpl <em>Drive System</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see SelfDrivingCar.impl.DriveSystemImpl
	 * @see SelfDrivingCar.impl.SelfDrivingCarPackageImpl#getDriveSystem()
	 * @generated
	 */
	int DRIVE_SYSTEM = 2;

	/**
	 * The feature id for the '<em><b>Motor Controller</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DRIVE_SYSTEM__MOTOR_CONTROLLER = 0;

	/**
	 * The feature id for the '<em><b>Brake Controller</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DRIVE_SYSTEM__BRAKE_CONTROLLER = 1;

	/**
	 * The feature id for the '<em><b>Steering Controller</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DRIVE_SYSTEM__STEERING_CONTROLLER = 2;

	/**
	 * The number of structural features of the '<em>Drive System</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DRIVE_SYSTEM_FEATURE_COUNT = 3;

	/**
	 * The operation id for the '<em>Accelerate</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DRIVE_SYSTEM___ACCELERATE__FLOAT = 0;

	/**
	 * The operation id for the '<em>Brake</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DRIVE_SYSTEM___BRAKE = 1;

	/**
	 * The operation id for the '<em>Steer</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DRIVE_SYSTEM___STEER__FLOAT = 2;

	/**
	 * The number of operations of the '<em>Drive System</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DRIVE_SYSTEM_OPERATION_COUNT = 3;

	/**
	 * The meta object id for the '{@link SelfDrivingCar.impl.MotorControllerImpl <em>Motor Controller</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see SelfDrivingCar.impl.MotorControllerImpl
	 * @see SelfDrivingCar.impl.SelfDrivingCarPackageImpl#getMotorController()
	 * @generated
	 */
	int MOTOR_CONTROLLER = 3;

	/**
	 * The feature id for the '<em><b>Motor Temperature</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOTOR_CONTROLLER__MOTOR_TEMPERATURE = 0;

	/**
	 * The number of structural features of the '<em>Motor Controller</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOTOR_CONTROLLER_FEATURE_COUNT = 1;

	/**
	 * The operation id for the '<em>Set Speed</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOTOR_CONTROLLER___SET_SPEED__FLOAT = 0;

	/**
	 * The number of operations of the '<em>Motor Controller</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOTOR_CONTROLLER_OPERATION_COUNT = 1;

	/**
	 * The meta object id for the '{@link SelfDrivingCar.impl.BrakeControllerImpl <em>Brake Controller</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see SelfDrivingCar.impl.BrakeControllerImpl
	 * @see SelfDrivingCar.impl.SelfDrivingCarPackageImpl#getBrakeController()
	 * @generated
	 */
	int BRAKE_CONTROLLER = 4;

	/**
	 * The feature id for the '<em><b>Brake Temperature</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BRAKE_CONTROLLER__BRAKE_TEMPERATURE = 0;

	/**
	 * The number of structural features of the '<em>Brake Controller</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BRAKE_CONTROLLER_FEATURE_COUNT = 1;

	/**
	 * The operation id for the '<em>Apply Brakes</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BRAKE_CONTROLLER___APPLY_BRAKES = 0;

	/**
	 * The number of operations of the '<em>Brake Controller</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BRAKE_CONTROLLER_OPERATION_COUNT = 1;

	/**
	 * The meta object id for the '{@link SelfDrivingCar.impl.SteeringControllerImpl <em>Steering Controller</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see SelfDrivingCar.impl.SteeringControllerImpl
	 * @see SelfDrivingCar.impl.SelfDrivingCarPackageImpl#getSteeringController()
	 * @generated
	 */
	int STEERING_CONTROLLER = 5;

	/**
	 * The feature id for the '<em><b>Steering Mode</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STEERING_CONTROLLER__STEERING_MODE = 0;

	/**
	 * The number of structural features of the '<em>Steering Controller</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STEERING_CONTROLLER_FEATURE_COUNT = 1;

	/**
	 * The operation id for the '<em>Set Steering Angle</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STEERING_CONTROLLER___SET_STEERING_ANGLE__FLOAT = 0;

	/**
	 * The number of operations of the '<em>Steering Controller</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STEERING_CONTROLLER_OPERATION_COUNT = 1;

	/**
	 * The meta object id for the '{@link SelfDrivingCar.impl.SensorImpl <em>Sensor</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see SelfDrivingCar.impl.SensorImpl
	 * @see SelfDrivingCar.impl.SelfDrivingCarPackageImpl#getSensor()
	 * @generated
	 */
	int SENSOR = 6;

	/**
	 * The feature id for the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SENSOR__TYPE = 0;

	/**
	 * The number of structural features of the '<em>Sensor</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SENSOR_FEATURE_COUNT = 1;

	/**
	 * The operation id for the '<em>Get Data</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SENSOR___GET_DATA = 0;

	/**
	 * The number of operations of the '<em>Sensor</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SENSOR_OPERATION_COUNT = 1;

	/**
	 * The meta object id for the '{@link SelfDrivingCar.impl.SensorDataImpl <em>Sensor Data</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see SelfDrivingCar.impl.SensorDataImpl
	 * @see SelfDrivingCar.impl.SelfDrivingCarPackageImpl#getSensorData()
	 * @generated
	 */
	int SENSOR_DATA = 7;

	/**
	 * The feature id for the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SENSOR_DATA__TYPE = 0;

	/**
	 * The feature id for the '<em><b>Data</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SENSOR_DATA__DATA = 1;

	/**
	 * The number of structural features of the '<em>Sensor Data</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SENSOR_DATA_FEATURE_COUNT = 2;

	/**
	 * The operation id for the '<em>Get Data Type</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SENSOR_DATA___GET_DATA_TYPE = 0;

	/**
	 * The number of operations of the '<em>Sensor Data</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SENSOR_DATA_OPERATION_COUNT = 1;

	/**
	 * The meta object id for the '{@link SelfDrivingCar.impl.CameraSensorImpl <em>Camera Sensor</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see SelfDrivingCar.impl.CameraSensorImpl
	 * @see SelfDrivingCar.impl.SelfDrivingCarPackageImpl#getCameraSensor()
	 * @generated
	 */
	int CAMERA_SENSOR = 8;

	/**
	 * The feature id for the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CAMERA_SENSOR__TYPE = SENSOR__TYPE;

	/**
	 * The feature id for the '<em><b>Camera Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CAMERA_SENSOR__CAMERA_TYPE = SENSOR_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Camera Sensor</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CAMERA_SENSOR_FEATURE_COUNT = SENSOR_FEATURE_COUNT + 1;

	/**
	 * The operation id for the '<em>Get Data</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CAMERA_SENSOR___GET_DATA = SENSOR___GET_DATA;

	/**
	 * The operation id for the '<em>Capture Image</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CAMERA_SENSOR___CAPTURE_IMAGE = SENSOR_OPERATION_COUNT + 0;

	/**
	 * The number of operations of the '<em>Camera Sensor</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CAMERA_SENSOR_OPERATION_COUNT = SENSOR_OPERATION_COUNT + 1;

	/**
	 * The meta object id for the '{@link SelfDrivingCar.impl.LidarSensorImpl <em>Lidar Sensor</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see SelfDrivingCar.impl.LidarSensorImpl
	 * @see SelfDrivingCar.impl.SelfDrivingCarPackageImpl#getLidarSensor()
	 * @generated
	 */
	int LIDAR_SENSOR = 9;

	/**
	 * The feature id for the '<em><b>Lidar Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIDAR_SENSOR__LIDAR_TYPE = 0;

	/**
	 * The number of structural features of the '<em>Lidar Sensor</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIDAR_SENSOR_FEATURE_COUNT = 1;

	/**
	 * The operation id for the '<em>Scan Environment</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIDAR_SENSOR___SCAN_ENVIRONMENT = 0;

	/**
	 * The number of operations of the '<em>Lidar Sensor</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIDAR_SENSOR_OPERATION_COUNT = 1;

	/**
	 * The meta object id for the '{@link SelfDrivingCar.impl.NavigationSystemImpl <em>Navigation System</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see SelfDrivingCar.impl.NavigationSystemImpl
	 * @see SelfDrivingCar.impl.SelfDrivingCarPackageImpl#getNavigationSystem()
	 * @generated
	 */
	int NAVIGATION_SYSTEM = 10;

	/**
	 * The feature id for the '<em><b>Map</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NAVIGATION_SYSTEM__MAP = 0;

	/**
	 * The number of structural features of the '<em>Navigation System</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NAVIGATION_SYSTEM_FEATURE_COUNT = 1;

	/**
	 * The operation id for the '<em>Calculate Route</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NAVIGATION_SYSTEM___CALCULATE_ROUTE = 0;

	/**
	 * The number of operations of the '<em>Navigation System</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NAVIGATION_SYSTEM_OPERATION_COUNT = 1;

	/**
	 * The meta object id for the '{@link SelfDrivingCar.impl.ControlUnitImpl <em>Control Unit</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see SelfDrivingCar.impl.ControlUnitImpl
	 * @see SelfDrivingCar.impl.SelfDrivingCarPackageImpl#getControlUnit()
	 * @generated
	 */
	int CONTROL_UNIT = 11;

	/**
	 * The feature id for the '<em><b>Processing Power</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTROL_UNIT__PROCESSING_POWER = 0;

	/**
	 * The number of structural features of the '<em>Control Unit</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTROL_UNIT_FEATURE_COUNT = 1;

	/**
	 * The operation id for the '<em>Process Input</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTROL_UNIT___PROCESS_INPUT = 0;

	/**
	 * The number of operations of the '<em>Control Unit</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTROL_UNIT_OPERATION_COUNT = 1;

	/**
	 * The meta object id for the '{@link SelfDrivingCar.impl.CommunicationModuleImpl <em>Communication Module</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see SelfDrivingCar.impl.CommunicationModuleImpl
	 * @see SelfDrivingCar.impl.SelfDrivingCarPackageImpl#getCommunicationModule()
	 * @generated
	 */
	int COMMUNICATION_MODULE = 12;

	/**
	 * The feature id for the '<em><b>Connection Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMMUNICATION_MODULE__CONNECTION_TYPE = 0;

	/**
	 * The feature id for the '<em><b>Data Transfer Rate</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMMUNICATION_MODULE__DATA_TRANSFER_RATE = 1;

	/**
	 * The number of structural features of the '<em>Communication Module</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMMUNICATION_MODULE_FEATURE_COUNT = 2;

	/**
	 * The operation id for the '<em>Send Data</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMMUNICATION_MODULE___SEND_DATA = 0;

	/**
	 * The operation id for the '<em>Receive Data</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMMUNICATION_MODULE___RECEIVE_DATA = 1;

	/**
	 * The number of operations of the '<em>Communication Module</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMMUNICATION_MODULE_OPERATION_COUNT = 2;


	/**
	 * Returns the meta object for class '{@link SelfDrivingCar.SelfDrivingCar <em>Self Driving Car</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Self Driving Car</em>'.
	 * @see SelfDrivingCar.SelfDrivingCar
	 * @generated
	 */
	EClass getSelfDrivingCar();

	/**
	 * Returns the meta object for the attribute '{@link SelfDrivingCar.SelfDrivingCar#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see SelfDrivingCar.SelfDrivingCar#getName()
	 * @see #getSelfDrivingCar()
	 * @generated
	 */
	EAttribute getSelfDrivingCar_Name();

	/**
	 * Returns the meta object for the '{@link SelfDrivingCar.SelfDrivingCar#start() <em>Start</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Start</em>' operation.
	 * @see SelfDrivingCar.SelfDrivingCar#start()
	 * @generated
	 */
	EOperation getSelfDrivingCar__Start();

	/**
	 * Returns the meta object for the '{@link SelfDrivingCar.SelfDrivingCar#stop() <em>Stop</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Stop</em>' operation.
	 * @see SelfDrivingCar.SelfDrivingCar#stop()
	 * @generated
	 */
	EOperation getSelfDrivingCar__Stop();

	/**
	 * Returns the meta object for the '{@link SelfDrivingCar.SelfDrivingCar#navigateTo(SelfDrivingCar.Location) <em>Navigate To</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Navigate To</em>' operation.
	 * @see SelfDrivingCar.SelfDrivingCar#navigateTo(SelfDrivingCar.Location)
	 * @generated
	 */
	EOperation getSelfDrivingCar__NavigateTo__Location();

	/**
	 * Returns the meta object for the '{@link SelfDrivingCar.SelfDrivingCar#updateSensors() <em>Update Sensors</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Update Sensors</em>' operation.
	 * @see SelfDrivingCar.SelfDrivingCar#updateSensors()
	 * @generated
	 */
	EOperation getSelfDrivingCar__UpdateSensors();

	/**
	 * Returns the meta object for the '{@link SelfDrivingCar.SelfDrivingCar#processSensorData() <em>Process Sensor Data</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Process Sensor Data</em>' operation.
	 * @see SelfDrivingCar.SelfDrivingCar#processSensorData()
	 * @generated
	 */
	EOperation getSelfDrivingCar__ProcessSensorData();

	/**
	 * Returns the meta object for the '{@link SelfDrivingCar.SelfDrivingCar#makeDecision() <em>Make Decision</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Make Decision</em>' operation.
	 * @see SelfDrivingCar.SelfDrivingCar#makeDecision()
	 * @generated
	 */
	EOperation getSelfDrivingCar__MakeDecision();

	/**
	 * Returns the meta object for the '{@link SelfDrivingCar.SelfDrivingCar#communicateWithCentralSystem() <em>Communicate With Central System</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Communicate With Central System</em>' operation.
	 * @see SelfDrivingCar.SelfDrivingCar#communicateWithCentralSystem()
	 * @generated
	 */
	EOperation getSelfDrivingCar__CommunicateWithCentralSystem();

	/**
	 * Returns the meta object for the '{@link SelfDrivingCar.SelfDrivingCar#executeDriveCommand() <em>Execute Drive Command</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Execute Drive Command</em>' operation.
	 * @see SelfDrivingCar.SelfDrivingCar#executeDriveCommand()
	 * @generated
	 */
	EOperation getSelfDrivingCar__ExecuteDriveCommand();

	/**
	 * Returns the meta object for class '{@link SelfDrivingCar.Location <em>Location</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Location</em>'.
	 * @see SelfDrivingCar.Location
	 * @generated
	 */
	EClass getLocation();

	/**
	 * Returns the meta object for the attribute '{@link SelfDrivingCar.Location#getLatitude <em>Latitude</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Latitude</em>'.
	 * @see SelfDrivingCar.Location#getLatitude()
	 * @see #getLocation()
	 * @generated
	 */
	EAttribute getLocation_Latitude();

	/**
	 * Returns the meta object for the attribute '{@link SelfDrivingCar.Location#getLongitude <em>Longitude</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Longitude</em>'.
	 * @see SelfDrivingCar.Location#getLongitude()
	 * @see #getLocation()
	 * @generated
	 */
	EAttribute getLocation_Longitude();

	/**
	 * Returns the meta object for the '{@link SelfDrivingCar.Location#getDetails() <em>Get Details</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Get Details</em>' operation.
	 * @see SelfDrivingCar.Location#getDetails()
	 * @generated
	 */
	EOperation getLocation__GetDetails();

	/**
	 * Returns the meta object for class '{@link SelfDrivingCar.DriveSystem <em>Drive System</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Drive System</em>'.
	 * @see SelfDrivingCar.DriveSystem
	 * @generated
	 */
	EClass getDriveSystem();

	/**
	 * Returns the meta object for the reference '{@link SelfDrivingCar.DriveSystem#getMotorController <em>Motor Controller</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Motor Controller</em>'.
	 * @see SelfDrivingCar.DriveSystem#getMotorController()
	 * @see #getDriveSystem()
	 * @generated
	 */
	EReference getDriveSystem_MotorController();

	/**
	 * Returns the meta object for the reference '{@link SelfDrivingCar.DriveSystem#getBrakeController <em>Brake Controller</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Brake Controller</em>'.
	 * @see SelfDrivingCar.DriveSystem#getBrakeController()
	 * @see #getDriveSystem()
	 * @generated
	 */
	EReference getDriveSystem_BrakeController();

	/**
	 * Returns the meta object for the reference '{@link SelfDrivingCar.DriveSystem#getSteeringController <em>Steering Controller</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Steering Controller</em>'.
	 * @see SelfDrivingCar.DriveSystem#getSteeringController()
	 * @see #getDriveSystem()
	 * @generated
	 */
	EReference getDriveSystem_SteeringController();

	/**
	 * Returns the meta object for the '{@link SelfDrivingCar.DriveSystem#accelerate(float) <em>Accelerate</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Accelerate</em>' operation.
	 * @see SelfDrivingCar.DriveSystem#accelerate(float)
	 * @generated
	 */
	EOperation getDriveSystem__Accelerate__float();

	/**
	 * Returns the meta object for the '{@link SelfDrivingCar.DriveSystem#brake() <em>Brake</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Brake</em>' operation.
	 * @see SelfDrivingCar.DriveSystem#brake()
	 * @generated
	 */
	EOperation getDriveSystem__Brake();

	/**
	 * Returns the meta object for the '{@link SelfDrivingCar.DriveSystem#steer(float) <em>Steer</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Steer</em>' operation.
	 * @see SelfDrivingCar.DriveSystem#steer(float)
	 * @generated
	 */
	EOperation getDriveSystem__Steer__float();

	/**
	 * Returns the meta object for class '{@link SelfDrivingCar.MotorController <em>Motor Controller</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Motor Controller</em>'.
	 * @see SelfDrivingCar.MotorController
	 * @generated
	 */
	EClass getMotorController();

	/**
	 * Returns the meta object for the attribute '{@link SelfDrivingCar.MotorController#getMotorTemperature <em>Motor Temperature</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Motor Temperature</em>'.
	 * @see SelfDrivingCar.MotorController#getMotorTemperature()
	 * @see #getMotorController()
	 * @generated
	 */
	EAttribute getMotorController_MotorTemperature();

	/**
	 * Returns the meta object for the '{@link SelfDrivingCar.MotorController#setSpeed(float) <em>Set Speed</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set Speed</em>' operation.
	 * @see SelfDrivingCar.MotorController#setSpeed(float)
	 * @generated
	 */
	EOperation getMotorController__SetSpeed__float();

	/**
	 * Returns the meta object for class '{@link SelfDrivingCar.BrakeController <em>Brake Controller</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Brake Controller</em>'.
	 * @see SelfDrivingCar.BrakeController
	 * @generated
	 */
	EClass getBrakeController();

	/**
	 * Returns the meta object for the attribute '{@link SelfDrivingCar.BrakeController#getBrakeTemperature <em>Brake Temperature</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Brake Temperature</em>'.
	 * @see SelfDrivingCar.BrakeController#getBrakeTemperature()
	 * @see #getBrakeController()
	 * @generated
	 */
	EAttribute getBrakeController_BrakeTemperature();

	/**
	 * Returns the meta object for the '{@link SelfDrivingCar.BrakeController#applyBrakes() <em>Apply Brakes</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Apply Brakes</em>' operation.
	 * @see SelfDrivingCar.BrakeController#applyBrakes()
	 * @generated
	 */
	EOperation getBrakeController__ApplyBrakes();

	/**
	 * Returns the meta object for class '{@link SelfDrivingCar.SteeringController <em>Steering Controller</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Steering Controller</em>'.
	 * @see SelfDrivingCar.SteeringController
	 * @generated
	 */
	EClass getSteeringController();

	/**
	 * Returns the meta object for the attribute '{@link SelfDrivingCar.SteeringController#getSteeringMode <em>Steering Mode</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Steering Mode</em>'.
	 * @see SelfDrivingCar.SteeringController#getSteeringMode()
	 * @see #getSteeringController()
	 * @generated
	 */
	EAttribute getSteeringController_SteeringMode();

	/**
	 * Returns the meta object for the '{@link SelfDrivingCar.SteeringController#setSteeringAngle(float) <em>Set Steering Angle</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Set Steering Angle</em>' operation.
	 * @see SelfDrivingCar.SteeringController#setSteeringAngle(float)
	 * @generated
	 */
	EOperation getSteeringController__SetSteeringAngle__float();

	/**
	 * Returns the meta object for class '{@link SelfDrivingCar.Sensor <em>Sensor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Sensor</em>'.
	 * @see SelfDrivingCar.Sensor
	 * @generated
	 */
	EClass getSensor();

	/**
	 * Returns the meta object for the attribute '{@link SelfDrivingCar.Sensor#getType <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Type</em>'.
	 * @see SelfDrivingCar.Sensor#getType()
	 * @see #getSensor()
	 * @generated
	 */
	EAttribute getSensor_Type();

	/**
	 * Returns the meta object for the '{@link SelfDrivingCar.Sensor#getData() <em>Get Data</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Get Data</em>' operation.
	 * @see SelfDrivingCar.Sensor#getData()
	 * @generated
	 */
	EOperation getSensor__GetData();

	/**
	 * Returns the meta object for class '{@link SelfDrivingCar.SensorData <em>Sensor Data</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Sensor Data</em>'.
	 * @see SelfDrivingCar.SensorData
	 * @generated
	 */
	EClass getSensorData();

	/**
	 * Returns the meta object for the attribute '{@link SelfDrivingCar.SensorData#getType <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Type</em>'.
	 * @see SelfDrivingCar.SensorData#getType()
	 * @see #getSensorData()
	 * @generated
	 */
	EAttribute getSensorData_Type();

	/**
	 * Returns the meta object for the attribute '{@link SelfDrivingCar.SensorData#getData <em>Data</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Data</em>'.
	 * @see SelfDrivingCar.SensorData#getData()
	 * @see #getSensorData()
	 * @generated
	 */
	EAttribute getSensorData_Data();

	/**
	 * Returns the meta object for the '{@link SelfDrivingCar.SensorData#getDataType() <em>Get Data Type</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Get Data Type</em>' operation.
	 * @see SelfDrivingCar.SensorData#getDataType()
	 * @generated
	 */
	EOperation getSensorData__GetDataType();

	/**
	 * Returns the meta object for class '{@link SelfDrivingCar.CameraSensor <em>Camera Sensor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Camera Sensor</em>'.
	 * @see SelfDrivingCar.CameraSensor
	 * @generated
	 */
	EClass getCameraSensor();

	/**
	 * Returns the meta object for the attribute '{@link SelfDrivingCar.CameraSensor#getCameraType <em>Camera Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Camera Type</em>'.
	 * @see SelfDrivingCar.CameraSensor#getCameraType()
	 * @see #getCameraSensor()
	 * @generated
	 */
	EAttribute getCameraSensor_CameraType();

	/**
	 * Returns the meta object for the '{@link SelfDrivingCar.CameraSensor#captureImage() <em>Capture Image</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Capture Image</em>' operation.
	 * @see SelfDrivingCar.CameraSensor#captureImage()
	 * @generated
	 */
	EOperation getCameraSensor__CaptureImage();

	/**
	 * Returns the meta object for class '{@link SelfDrivingCar.LidarSensor <em>Lidar Sensor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Lidar Sensor</em>'.
	 * @see SelfDrivingCar.LidarSensor
	 * @generated
	 */
	EClass getLidarSensor();

	/**
	 * Returns the meta object for the attribute '{@link SelfDrivingCar.LidarSensor#getLidarType <em>Lidar Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Lidar Type</em>'.
	 * @see SelfDrivingCar.LidarSensor#getLidarType()
	 * @see #getLidarSensor()
	 * @generated
	 */
	EAttribute getLidarSensor_LidarType();

	/**
	 * Returns the meta object for the '{@link SelfDrivingCar.LidarSensor#scanEnvironment() <em>Scan Environment</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Scan Environment</em>' operation.
	 * @see SelfDrivingCar.LidarSensor#scanEnvironment()
	 * @generated
	 */
	EOperation getLidarSensor__ScanEnvironment();

	/**
	 * Returns the meta object for class '{@link SelfDrivingCar.NavigationSystem <em>Navigation System</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Navigation System</em>'.
	 * @see SelfDrivingCar.NavigationSystem
	 * @generated
	 */
	EClass getNavigationSystem();

	/**
	 * Returns the meta object for the attribute '{@link SelfDrivingCar.NavigationSystem#getMap <em>Map</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Map</em>'.
	 * @see SelfDrivingCar.NavigationSystem#getMap()
	 * @see #getNavigationSystem()
	 * @generated
	 */
	EAttribute getNavigationSystem_Map();

	/**
	 * Returns the meta object for the '{@link SelfDrivingCar.NavigationSystem#calculateRoute() <em>Calculate Route</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Calculate Route</em>' operation.
	 * @see SelfDrivingCar.NavigationSystem#calculateRoute()
	 * @generated
	 */
	EOperation getNavigationSystem__CalculateRoute();

	/**
	 * Returns the meta object for class '{@link SelfDrivingCar.ControlUnit <em>Control Unit</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Control Unit</em>'.
	 * @see SelfDrivingCar.ControlUnit
	 * @generated
	 */
	EClass getControlUnit();

	/**
	 * Returns the meta object for the attribute '{@link SelfDrivingCar.ControlUnit#getProcessingPower <em>Processing Power</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Processing Power</em>'.
	 * @see SelfDrivingCar.ControlUnit#getProcessingPower()
	 * @see #getControlUnit()
	 * @generated
	 */
	EAttribute getControlUnit_ProcessingPower();

	/**
	 * Returns the meta object for the '{@link SelfDrivingCar.ControlUnit#processInput() <em>Process Input</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Process Input</em>' operation.
	 * @see SelfDrivingCar.ControlUnit#processInput()
	 * @generated
	 */
	EOperation getControlUnit__ProcessInput();

	/**
	 * Returns the meta object for class '{@link SelfDrivingCar.CommunicationModule <em>Communication Module</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Communication Module</em>'.
	 * @see SelfDrivingCar.CommunicationModule
	 * @generated
	 */
	EClass getCommunicationModule();

	/**
	 * Returns the meta object for the attribute '{@link SelfDrivingCar.CommunicationModule#getConnectionType <em>Connection Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Connection Type</em>'.
	 * @see SelfDrivingCar.CommunicationModule#getConnectionType()
	 * @see #getCommunicationModule()
	 * @generated
	 */
	EAttribute getCommunicationModule_ConnectionType();

	/**
	 * Returns the meta object for the attribute '{@link SelfDrivingCar.CommunicationModule#getDataTransferRate <em>Data Transfer Rate</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Data Transfer Rate</em>'.
	 * @see SelfDrivingCar.CommunicationModule#getDataTransferRate()
	 * @see #getCommunicationModule()
	 * @generated
	 */
	EAttribute getCommunicationModule_DataTransferRate();

	/**
	 * Returns the meta object for the '{@link SelfDrivingCar.CommunicationModule#sendData() <em>Send Data</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Send Data</em>' operation.
	 * @see SelfDrivingCar.CommunicationModule#sendData()
	 * @generated
	 */
	EOperation getCommunicationModule__SendData();

	/**
	 * Returns the meta object for the '{@link SelfDrivingCar.CommunicationModule#receiveData() <em>Receive Data</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Receive Data</em>' operation.
	 * @see SelfDrivingCar.CommunicationModule#receiveData()
	 * @generated
	 */
	EOperation getCommunicationModule__ReceiveData();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	SelfDrivingCarFactory getSelfDrivingCarFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link SelfDrivingCar.impl.SelfDrivingCarImpl <em>Self Driving Car</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see SelfDrivingCar.impl.SelfDrivingCarImpl
		 * @see SelfDrivingCar.impl.SelfDrivingCarPackageImpl#getSelfDrivingCar()
		 * @generated
		 */
		EClass SELF_DRIVING_CAR = eINSTANCE.getSelfDrivingCar();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SELF_DRIVING_CAR__NAME = eINSTANCE.getSelfDrivingCar_Name();

		/**
		 * The meta object literal for the '<em><b>Start</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation SELF_DRIVING_CAR___START = eINSTANCE.getSelfDrivingCar__Start();

		/**
		 * The meta object literal for the '<em><b>Stop</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation SELF_DRIVING_CAR___STOP = eINSTANCE.getSelfDrivingCar__Stop();

		/**
		 * The meta object literal for the '<em><b>Navigate To</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation SELF_DRIVING_CAR___NAVIGATE_TO__LOCATION = eINSTANCE.getSelfDrivingCar__NavigateTo__Location();

		/**
		 * The meta object literal for the '<em><b>Update Sensors</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation SELF_DRIVING_CAR___UPDATE_SENSORS = eINSTANCE.getSelfDrivingCar__UpdateSensors();

		/**
		 * The meta object literal for the '<em><b>Process Sensor Data</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation SELF_DRIVING_CAR___PROCESS_SENSOR_DATA = eINSTANCE.getSelfDrivingCar__ProcessSensorData();

		/**
		 * The meta object literal for the '<em><b>Make Decision</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation SELF_DRIVING_CAR___MAKE_DECISION = eINSTANCE.getSelfDrivingCar__MakeDecision();

		/**
		 * The meta object literal for the '<em><b>Communicate With Central System</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation SELF_DRIVING_CAR___COMMUNICATE_WITH_CENTRAL_SYSTEM = eINSTANCE.getSelfDrivingCar__CommunicateWithCentralSystem();

		/**
		 * The meta object literal for the '<em><b>Execute Drive Command</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation SELF_DRIVING_CAR___EXECUTE_DRIVE_COMMAND = eINSTANCE.getSelfDrivingCar__ExecuteDriveCommand();

		/**
		 * The meta object literal for the '{@link SelfDrivingCar.impl.LocationImpl <em>Location</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see SelfDrivingCar.impl.LocationImpl
		 * @see SelfDrivingCar.impl.SelfDrivingCarPackageImpl#getLocation()
		 * @generated
		 */
		EClass LOCATION = eINSTANCE.getLocation();

		/**
		 * The meta object literal for the '<em><b>Latitude</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute LOCATION__LATITUDE = eINSTANCE.getLocation_Latitude();

		/**
		 * The meta object literal for the '<em><b>Longitude</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute LOCATION__LONGITUDE = eINSTANCE.getLocation_Longitude();

		/**
		 * The meta object literal for the '<em><b>Get Details</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation LOCATION___GET_DETAILS = eINSTANCE.getLocation__GetDetails();

		/**
		 * The meta object literal for the '{@link SelfDrivingCar.impl.DriveSystemImpl <em>Drive System</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see SelfDrivingCar.impl.DriveSystemImpl
		 * @see SelfDrivingCar.impl.SelfDrivingCarPackageImpl#getDriveSystem()
		 * @generated
		 */
		EClass DRIVE_SYSTEM = eINSTANCE.getDriveSystem();

		/**
		 * The meta object literal for the '<em><b>Motor Controller</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DRIVE_SYSTEM__MOTOR_CONTROLLER = eINSTANCE.getDriveSystem_MotorController();

		/**
		 * The meta object literal for the '<em><b>Brake Controller</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DRIVE_SYSTEM__BRAKE_CONTROLLER = eINSTANCE.getDriveSystem_BrakeController();

		/**
		 * The meta object literal for the '<em><b>Steering Controller</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DRIVE_SYSTEM__STEERING_CONTROLLER = eINSTANCE.getDriveSystem_SteeringController();

		/**
		 * The meta object literal for the '<em><b>Accelerate</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation DRIVE_SYSTEM___ACCELERATE__FLOAT = eINSTANCE.getDriveSystem__Accelerate__float();

		/**
		 * The meta object literal for the '<em><b>Brake</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation DRIVE_SYSTEM___BRAKE = eINSTANCE.getDriveSystem__Brake();

		/**
		 * The meta object literal for the '<em><b>Steer</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation DRIVE_SYSTEM___STEER__FLOAT = eINSTANCE.getDriveSystem__Steer__float();

		/**
		 * The meta object literal for the '{@link SelfDrivingCar.impl.MotorControllerImpl <em>Motor Controller</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see SelfDrivingCar.impl.MotorControllerImpl
		 * @see SelfDrivingCar.impl.SelfDrivingCarPackageImpl#getMotorController()
		 * @generated
		 */
		EClass MOTOR_CONTROLLER = eINSTANCE.getMotorController();

		/**
		 * The meta object literal for the '<em><b>Motor Temperature</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MOTOR_CONTROLLER__MOTOR_TEMPERATURE = eINSTANCE.getMotorController_MotorTemperature();

		/**
		 * The meta object literal for the '<em><b>Set Speed</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation MOTOR_CONTROLLER___SET_SPEED__FLOAT = eINSTANCE.getMotorController__SetSpeed__float();

		/**
		 * The meta object literal for the '{@link SelfDrivingCar.impl.BrakeControllerImpl <em>Brake Controller</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see SelfDrivingCar.impl.BrakeControllerImpl
		 * @see SelfDrivingCar.impl.SelfDrivingCarPackageImpl#getBrakeController()
		 * @generated
		 */
		EClass BRAKE_CONTROLLER = eINSTANCE.getBrakeController();

		/**
		 * The meta object literal for the '<em><b>Brake Temperature</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute BRAKE_CONTROLLER__BRAKE_TEMPERATURE = eINSTANCE.getBrakeController_BrakeTemperature();

		/**
		 * The meta object literal for the '<em><b>Apply Brakes</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation BRAKE_CONTROLLER___APPLY_BRAKES = eINSTANCE.getBrakeController__ApplyBrakes();

		/**
		 * The meta object literal for the '{@link SelfDrivingCar.impl.SteeringControllerImpl <em>Steering Controller</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see SelfDrivingCar.impl.SteeringControllerImpl
		 * @see SelfDrivingCar.impl.SelfDrivingCarPackageImpl#getSteeringController()
		 * @generated
		 */
		EClass STEERING_CONTROLLER = eINSTANCE.getSteeringController();

		/**
		 * The meta object literal for the '<em><b>Steering Mode</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute STEERING_CONTROLLER__STEERING_MODE = eINSTANCE.getSteeringController_SteeringMode();

		/**
		 * The meta object literal for the '<em><b>Set Steering Angle</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation STEERING_CONTROLLER___SET_STEERING_ANGLE__FLOAT = eINSTANCE.getSteeringController__SetSteeringAngle__float();

		/**
		 * The meta object literal for the '{@link SelfDrivingCar.impl.SensorImpl <em>Sensor</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see SelfDrivingCar.impl.SensorImpl
		 * @see SelfDrivingCar.impl.SelfDrivingCarPackageImpl#getSensor()
		 * @generated
		 */
		EClass SENSOR = eINSTANCE.getSensor();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SENSOR__TYPE = eINSTANCE.getSensor_Type();

		/**
		 * The meta object literal for the '<em><b>Get Data</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation SENSOR___GET_DATA = eINSTANCE.getSensor__GetData();

		/**
		 * The meta object literal for the '{@link SelfDrivingCar.impl.SensorDataImpl <em>Sensor Data</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see SelfDrivingCar.impl.SensorDataImpl
		 * @see SelfDrivingCar.impl.SelfDrivingCarPackageImpl#getSensorData()
		 * @generated
		 */
		EClass SENSOR_DATA = eINSTANCE.getSensorData();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SENSOR_DATA__TYPE = eINSTANCE.getSensorData_Type();

		/**
		 * The meta object literal for the '<em><b>Data</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SENSOR_DATA__DATA = eINSTANCE.getSensorData_Data();

		/**
		 * The meta object literal for the '<em><b>Get Data Type</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation SENSOR_DATA___GET_DATA_TYPE = eINSTANCE.getSensorData__GetDataType();

		/**
		 * The meta object literal for the '{@link SelfDrivingCar.impl.CameraSensorImpl <em>Camera Sensor</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see SelfDrivingCar.impl.CameraSensorImpl
		 * @see SelfDrivingCar.impl.SelfDrivingCarPackageImpl#getCameraSensor()
		 * @generated
		 */
		EClass CAMERA_SENSOR = eINSTANCE.getCameraSensor();

		/**
		 * The meta object literal for the '<em><b>Camera Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CAMERA_SENSOR__CAMERA_TYPE = eINSTANCE.getCameraSensor_CameraType();

		/**
		 * The meta object literal for the '<em><b>Capture Image</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation CAMERA_SENSOR___CAPTURE_IMAGE = eINSTANCE.getCameraSensor__CaptureImage();

		/**
		 * The meta object literal for the '{@link SelfDrivingCar.impl.LidarSensorImpl <em>Lidar Sensor</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see SelfDrivingCar.impl.LidarSensorImpl
		 * @see SelfDrivingCar.impl.SelfDrivingCarPackageImpl#getLidarSensor()
		 * @generated
		 */
		EClass LIDAR_SENSOR = eINSTANCE.getLidarSensor();

		/**
		 * The meta object literal for the '<em><b>Lidar Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute LIDAR_SENSOR__LIDAR_TYPE = eINSTANCE.getLidarSensor_LidarType();

		/**
		 * The meta object literal for the '<em><b>Scan Environment</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation LIDAR_SENSOR___SCAN_ENVIRONMENT = eINSTANCE.getLidarSensor__ScanEnvironment();

		/**
		 * The meta object literal for the '{@link SelfDrivingCar.impl.NavigationSystemImpl <em>Navigation System</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see SelfDrivingCar.impl.NavigationSystemImpl
		 * @see SelfDrivingCar.impl.SelfDrivingCarPackageImpl#getNavigationSystem()
		 * @generated
		 */
		EClass NAVIGATION_SYSTEM = eINSTANCE.getNavigationSystem();

		/**
		 * The meta object literal for the '<em><b>Map</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute NAVIGATION_SYSTEM__MAP = eINSTANCE.getNavigationSystem_Map();

		/**
		 * The meta object literal for the '<em><b>Calculate Route</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation NAVIGATION_SYSTEM___CALCULATE_ROUTE = eINSTANCE.getNavigationSystem__CalculateRoute();

		/**
		 * The meta object literal for the '{@link SelfDrivingCar.impl.ControlUnitImpl <em>Control Unit</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see SelfDrivingCar.impl.ControlUnitImpl
		 * @see SelfDrivingCar.impl.SelfDrivingCarPackageImpl#getControlUnit()
		 * @generated
		 */
		EClass CONTROL_UNIT = eINSTANCE.getControlUnit();

		/**
		 * The meta object literal for the '<em><b>Processing Power</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONTROL_UNIT__PROCESSING_POWER = eINSTANCE.getControlUnit_ProcessingPower();

		/**
		 * The meta object literal for the '<em><b>Process Input</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation CONTROL_UNIT___PROCESS_INPUT = eINSTANCE.getControlUnit__ProcessInput();

		/**
		 * The meta object literal for the '{@link SelfDrivingCar.impl.CommunicationModuleImpl <em>Communication Module</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see SelfDrivingCar.impl.CommunicationModuleImpl
		 * @see SelfDrivingCar.impl.SelfDrivingCarPackageImpl#getCommunicationModule()
		 * @generated
		 */
		EClass COMMUNICATION_MODULE = eINSTANCE.getCommunicationModule();

		/**
		 * The meta object literal for the '<em><b>Connection Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute COMMUNICATION_MODULE__CONNECTION_TYPE = eINSTANCE.getCommunicationModule_ConnectionType();

		/**
		 * The meta object literal for the '<em><b>Data Transfer Rate</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute COMMUNICATION_MODULE__DATA_TRANSFER_RATE = eINSTANCE.getCommunicationModule_DataTransferRate();

		/**
		 * The meta object literal for the '<em><b>Send Data</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation COMMUNICATION_MODULE___SEND_DATA = eINSTANCE.getCommunicationModule__SendData();

		/**
		 * The meta object literal for the '<em><b>Receive Data</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation COMMUNICATION_MODULE___RECEIVE_DATA = eINSTANCE.getCommunicationModule__ReceiveData();

	}

} //SelfDrivingCarPackage
