/**
 */
package SelfDrivingCar;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Brake Controller</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link SelfDrivingCar.BrakeController#getBrakeTemperature <em>Brake Temperature</em>}</li>
 * </ul>
 *
 * @see SelfDrivingCar.SelfDrivingCarPackage#getBrakeController()
 * @model
 * @generated
 */
public interface BrakeController extends EObject {
	/**
	 * Returns the value of the '<em><b>Brake Temperature</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Brake Temperature</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Brake Temperature</em>' attribute.
	 * @see #setBrakeTemperature(float)
	 * @see SelfDrivingCar.SelfDrivingCarPackage#getBrakeController_BrakeTemperature()
	 * @model required="true" ordered="false"
	 * @generated
	 */
	float getBrakeTemperature();

	/**
	 * Sets the value of the '{@link SelfDrivingCar.BrakeController#getBrakeTemperature <em>Brake Temperature</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Brake Temperature</em>' attribute.
	 * @see #getBrakeTemperature()
	 * @generated
	 */
	void setBrakeTemperature(float value);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void applyBrakes();

} // BrakeController
