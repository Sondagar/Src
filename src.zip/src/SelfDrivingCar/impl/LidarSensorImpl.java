/**
 */
package SelfDrivingCar.impl;

import SelfDrivingCar.LidarSensor;
import SelfDrivingCar.SelfDrivingCarPackage;

import java.lang.reflect.InvocationTargetException;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Lidar Sensor</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link SelfDrivingCar.impl.LidarSensorImpl#getLidarType <em>Lidar Type</em>}</li>
 * </ul>
 *
 * @generated
 */
public class LidarSensorImpl extends MinimalEObjectImpl.Container implements LidarSensor {
	/**
	 * The default value of the '{@link #getLidarType() <em>Lidar Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLidarType()
	 * @generated
	 * @ordered
	 */
	protected static final String LIDAR_TYPE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getLidarType() <em>Lidar Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLidarType()
	 * @generated
	 * @ordered
	 */
	protected String lidarType = LIDAR_TYPE_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected LidarSensorImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return SelfDrivingCarPackage.Literals.LIDAR_SENSOR;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getLidarType() {
		return lidarType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setLidarType(String newLidarType) {
		String oldLidarType = lidarType;
		lidarType = newLidarType;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SelfDrivingCarPackage.LIDAR_SENSOR__LIDAR_TYPE, oldLidarType, lidarType));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void scanEnvironment() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case SelfDrivingCarPackage.LIDAR_SENSOR__LIDAR_TYPE:
				return getLidarType();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case SelfDrivingCarPackage.LIDAR_SENSOR__LIDAR_TYPE:
				setLidarType((String)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case SelfDrivingCarPackage.LIDAR_SENSOR__LIDAR_TYPE:
				setLidarType(LIDAR_TYPE_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case SelfDrivingCarPackage.LIDAR_SENSOR__LIDAR_TYPE:
				return LIDAR_TYPE_EDEFAULT == null ? lidarType != null : !LIDAR_TYPE_EDEFAULT.equals(lidarType);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eInvoke(int operationID, EList<?> arguments) throws InvocationTargetException {
		switch (operationID) {
			case SelfDrivingCarPackage.LIDAR_SENSOR___SCAN_ENVIRONMENT:
				scanEnvironment();
				return null;
		}
		return super.eInvoke(operationID, arguments);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (lidarType: ");
		result.append(lidarType);
		result.append(')');
		return result.toString();
	}

} //LidarSensorImpl
