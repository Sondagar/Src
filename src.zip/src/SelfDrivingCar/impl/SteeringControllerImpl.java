/**
 */
package SelfDrivingCar.impl;

import SelfDrivingCar.SelfDrivingCarPackage;
import SelfDrivingCar.SteeringController;

import java.lang.reflect.InvocationTargetException;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Steering Controller</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link SelfDrivingCar.impl.SteeringControllerImpl#getSteeringMode <em>Steering Mode</em>}</li>
 * </ul>
 *
 * @generated
 */
public class SteeringControllerImpl extends MinimalEObjectImpl.Container implements SteeringController {
	/**
	 * The default value of the '{@link #getSteeringMode() <em>Steering Mode</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSteeringMode()
	 * @generated
	 * @ordered
	 */
	protected static final String STEERING_MODE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getSteeringMode() <em>Steering Mode</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSteeringMode()
	 * @generated
	 * @ordered
	 */
	protected String steeringMode = STEERING_MODE_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SteeringControllerImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return SelfDrivingCarPackage.Literals.STEERING_CONTROLLER;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getSteeringMode() {
		return steeringMode;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setSteeringMode(String newSteeringMode) {
		String oldSteeringMode = steeringMode;
		steeringMode = newSteeringMode;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SelfDrivingCarPackage.STEERING_CONTROLLER__STEERING_MODE, oldSteeringMode, steeringMode));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSteeringAngle(float angle) {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case SelfDrivingCarPackage.STEERING_CONTROLLER__STEERING_MODE:
				return getSteeringMode();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case SelfDrivingCarPackage.STEERING_CONTROLLER__STEERING_MODE:
				setSteeringMode((String)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case SelfDrivingCarPackage.STEERING_CONTROLLER__STEERING_MODE:
				setSteeringMode(STEERING_MODE_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case SelfDrivingCarPackage.STEERING_CONTROLLER__STEERING_MODE:
				return STEERING_MODE_EDEFAULT == null ? steeringMode != null : !STEERING_MODE_EDEFAULT.equals(steeringMode);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eInvoke(int operationID, EList<?> arguments) throws InvocationTargetException {
		switch (operationID) {
			case SelfDrivingCarPackage.STEERING_CONTROLLER___SET_STEERING_ANGLE__FLOAT:
				setSteeringAngle((Float)arguments.get(0));
				return null;
		}
		return super.eInvoke(operationID, arguments);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (steeringMode: ");
		result.append(steeringMode);
		result.append(')');
		return result.toString();
	}

} //SteeringControllerImpl
