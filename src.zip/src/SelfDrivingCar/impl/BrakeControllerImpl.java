/**
 */
package SelfDrivingCar.impl;

import SelfDrivingCar.BrakeController;
import SelfDrivingCar.SelfDrivingCarPackage;

import java.lang.reflect.InvocationTargetException;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Brake Controller</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link SelfDrivingCar.impl.BrakeControllerImpl#getBrakeTemperature <em>Brake Temperature</em>}</li>
 * </ul>
 *
 * @generated
 */
public class BrakeControllerImpl extends MinimalEObjectImpl.Container implements BrakeController {
	/**
	 * The default value of the '{@link #getBrakeTemperature() <em>Brake Temperature</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBrakeTemperature()
	 * @generated
	 * @ordered
	 */
	protected static final float BRAKE_TEMPERATURE_EDEFAULT = 0.0F;

	/**
	 * The cached value of the '{@link #getBrakeTemperature() <em>Brake Temperature</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBrakeTemperature()
	 * @generated
	 * @ordered
	 */
	protected float brakeTemperature = BRAKE_TEMPERATURE_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected BrakeControllerImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return SelfDrivingCarPackage.Literals.BRAKE_CONTROLLER;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public float getBrakeTemperature() {
		return brakeTemperature;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setBrakeTemperature(float newBrakeTemperature) {
		float oldBrakeTemperature = brakeTemperature;
		brakeTemperature = newBrakeTemperature;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SelfDrivingCarPackage.BRAKE_CONTROLLER__BRAKE_TEMPERATURE, oldBrakeTemperature, brakeTemperature));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void applyBrakes() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case SelfDrivingCarPackage.BRAKE_CONTROLLER__BRAKE_TEMPERATURE:
				return getBrakeTemperature();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case SelfDrivingCarPackage.BRAKE_CONTROLLER__BRAKE_TEMPERATURE:
				setBrakeTemperature((Float)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case SelfDrivingCarPackage.BRAKE_CONTROLLER__BRAKE_TEMPERATURE:
				setBrakeTemperature(BRAKE_TEMPERATURE_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case SelfDrivingCarPackage.BRAKE_CONTROLLER__BRAKE_TEMPERATURE:
				return brakeTemperature != BRAKE_TEMPERATURE_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eInvoke(int operationID, EList<?> arguments) throws InvocationTargetException {
		switch (operationID) {
			case SelfDrivingCarPackage.BRAKE_CONTROLLER___APPLY_BRAKES:
				applyBrakes();
				return null;
		}
		return super.eInvoke(operationID, arguments);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (brakeTemperature: ");
		result.append(brakeTemperature);
		result.append(')');
		return result.toString();
	}

} //BrakeControllerImpl
