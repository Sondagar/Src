/**
 */
package SelfDrivingCar.impl;

import SelfDrivingCar.BrakeController;
import SelfDrivingCar.DriveSystem;
import SelfDrivingCar.MotorController;
import SelfDrivingCar.SelfDrivingCarPackage;
import SelfDrivingCar.SteeringController;

import java.lang.reflect.InvocationTargetException;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Drive System</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link SelfDrivingCar.impl.DriveSystemImpl#getMotorController <em>Motor Controller</em>}</li>
 *   <li>{@link SelfDrivingCar.impl.DriveSystemImpl#getBrakeController <em>Brake Controller</em>}</li>
 *   <li>{@link SelfDrivingCar.impl.DriveSystemImpl#getSteeringController <em>Steering Controller</em>}</li>
 * </ul>
 *
 * @generated
 */
public class DriveSystemImpl extends MinimalEObjectImpl.Container implements DriveSystem {
	/**
	 * The cached value of the '{@link #getMotorController() <em>Motor Controller</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMotorController()
	 * @generated
	 * @ordered
	 */
	protected MotorController motorController;

	/**
	 * The cached value of the '{@link #getBrakeController() <em>Brake Controller</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBrakeController()
	 * @generated
	 * @ordered
	 */
	protected BrakeController brakeController;

	/**
	 * The cached value of the '{@link #getSteeringController() <em>Steering Controller</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSteeringController()
	 * @generated
	 * @ordered
	 */
	protected SteeringController steeringController;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DriveSystemImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return SelfDrivingCarPackage.Literals.DRIVE_SYSTEM;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public MotorController getMotorController() {
		if (motorController != null && motorController.eIsProxy()) {
			InternalEObject oldMotorController = (InternalEObject)motorController;
			motorController = (MotorController)eResolveProxy(oldMotorController);
			if (motorController != oldMotorController) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, SelfDrivingCarPackage.DRIVE_SYSTEM__MOTOR_CONTROLLER, oldMotorController, motorController));
			}
		}
		return motorController;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public MotorController basicGetMotorController() {
		return motorController;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setMotorController(MotorController newMotorController) {
		MotorController oldMotorController = motorController;
		motorController = newMotorController;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SelfDrivingCarPackage.DRIVE_SYSTEM__MOTOR_CONTROLLER, oldMotorController, motorController));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public BrakeController getBrakeController() {
		if (brakeController != null && brakeController.eIsProxy()) {
			InternalEObject oldBrakeController = (InternalEObject)brakeController;
			brakeController = (BrakeController)eResolveProxy(oldBrakeController);
			if (brakeController != oldBrakeController) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, SelfDrivingCarPackage.DRIVE_SYSTEM__BRAKE_CONTROLLER, oldBrakeController, brakeController));
			}
		}
		return brakeController;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public BrakeController basicGetBrakeController() {
		return brakeController;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setBrakeController(BrakeController newBrakeController) {
		BrakeController oldBrakeController = brakeController;
		brakeController = newBrakeController;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SelfDrivingCarPackage.DRIVE_SYSTEM__BRAKE_CONTROLLER, oldBrakeController, brakeController));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public SteeringController getSteeringController() {
		if (steeringController != null && steeringController.eIsProxy()) {
			InternalEObject oldSteeringController = (InternalEObject)steeringController;
			steeringController = (SteeringController)eResolveProxy(oldSteeringController);
			if (steeringController != oldSteeringController) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, SelfDrivingCarPackage.DRIVE_SYSTEM__STEERING_CONTROLLER, oldSteeringController, steeringController));
			}
		}
		return steeringController;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SteeringController basicGetSteeringController() {
		return steeringController;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setSteeringController(SteeringController newSteeringController) {
		SteeringController oldSteeringController = steeringController;
		steeringController = newSteeringController;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SelfDrivingCarPackage.DRIVE_SYSTEM__STEERING_CONTROLLER, oldSteeringController, steeringController));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void accelerate(float speed) {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void brake() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void steer(float angle) {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case SelfDrivingCarPackage.DRIVE_SYSTEM__MOTOR_CONTROLLER:
				if (resolve) return getMotorController();
				return basicGetMotorController();
			case SelfDrivingCarPackage.DRIVE_SYSTEM__BRAKE_CONTROLLER:
				if (resolve) return getBrakeController();
				return basicGetBrakeController();
			case SelfDrivingCarPackage.DRIVE_SYSTEM__STEERING_CONTROLLER:
				if (resolve) return getSteeringController();
				return basicGetSteeringController();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case SelfDrivingCarPackage.DRIVE_SYSTEM__MOTOR_CONTROLLER:
				setMotorController((MotorController)newValue);
				return;
			case SelfDrivingCarPackage.DRIVE_SYSTEM__BRAKE_CONTROLLER:
				setBrakeController((BrakeController)newValue);
				return;
			case SelfDrivingCarPackage.DRIVE_SYSTEM__STEERING_CONTROLLER:
				setSteeringController((SteeringController)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case SelfDrivingCarPackage.DRIVE_SYSTEM__MOTOR_CONTROLLER:
				setMotorController((MotorController)null);
				return;
			case SelfDrivingCarPackage.DRIVE_SYSTEM__BRAKE_CONTROLLER:
				setBrakeController((BrakeController)null);
				return;
			case SelfDrivingCarPackage.DRIVE_SYSTEM__STEERING_CONTROLLER:
				setSteeringController((SteeringController)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case SelfDrivingCarPackage.DRIVE_SYSTEM__MOTOR_CONTROLLER:
				return motorController != null;
			case SelfDrivingCarPackage.DRIVE_SYSTEM__BRAKE_CONTROLLER:
				return brakeController != null;
			case SelfDrivingCarPackage.DRIVE_SYSTEM__STEERING_CONTROLLER:
				return steeringController != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eInvoke(int operationID, EList<?> arguments) throws InvocationTargetException {
		switch (operationID) {
			case SelfDrivingCarPackage.DRIVE_SYSTEM___ACCELERATE__FLOAT:
				accelerate((Float)arguments.get(0));
				return null;
			case SelfDrivingCarPackage.DRIVE_SYSTEM___BRAKE:
				brake();
				return null;
			case SelfDrivingCarPackage.DRIVE_SYSTEM___STEER__FLOAT:
				steer((Float)arguments.get(0));
				return null;
		}
		return super.eInvoke(operationID, arguments);
	}

} //DriveSystemImpl
