/**
 */
package SelfDrivingCar.impl;

import SelfDrivingCar.CommunicationModule;
import SelfDrivingCar.SelfDrivingCarPackage;

import java.lang.reflect.InvocationTargetException;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Communication Module</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link SelfDrivingCar.impl.CommunicationModuleImpl#getConnectionType <em>Connection Type</em>}</li>
 *   <li>{@link SelfDrivingCar.impl.CommunicationModuleImpl#getDataTransferRate <em>Data Transfer Rate</em>}</li>
 * </ul>
 *
 * @generated
 */
public class CommunicationModuleImpl extends MinimalEObjectImpl.Container implements CommunicationModule {
	/**
	 * The default value of the '{@link #getConnectionType() <em>Connection Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getConnectionType()
	 * @generated
	 * @ordered
	 */
	protected static final String CONNECTION_TYPE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getConnectionType() <em>Connection Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getConnectionType()
	 * @generated
	 * @ordered
	 */
	protected String connectionType = CONNECTION_TYPE_EDEFAULT;

	/**
	 * The default value of the '{@link #getDataTransferRate() <em>Data Transfer Rate</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDataTransferRate()
	 * @generated
	 * @ordered
	 */
	protected static final int DATA_TRANSFER_RATE_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getDataTransferRate() <em>Data Transfer Rate</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDataTransferRate()
	 * @generated
	 * @ordered
	 */
	protected int dataTransferRate = DATA_TRANSFER_RATE_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected CommunicationModuleImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return SelfDrivingCarPackage.Literals.COMMUNICATION_MODULE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getConnectionType() {
		return connectionType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setConnectionType(String newConnectionType) {
		String oldConnectionType = connectionType;
		connectionType = newConnectionType;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SelfDrivingCarPackage.COMMUNICATION_MODULE__CONNECTION_TYPE, oldConnectionType, connectionType));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int getDataTransferRate() {
		return dataTransferRate;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setDataTransferRate(int newDataTransferRate) {
		int oldDataTransferRate = dataTransferRate;
		dataTransferRate = newDataTransferRate;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SelfDrivingCarPackage.COMMUNICATION_MODULE__DATA_TRANSFER_RATE, oldDataTransferRate, dataTransferRate));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void sendData() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void receiveData() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case SelfDrivingCarPackage.COMMUNICATION_MODULE__CONNECTION_TYPE:
				return getConnectionType();
			case SelfDrivingCarPackage.COMMUNICATION_MODULE__DATA_TRANSFER_RATE:
				return getDataTransferRate();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case SelfDrivingCarPackage.COMMUNICATION_MODULE__CONNECTION_TYPE:
				setConnectionType((String)newValue);
				return;
			case SelfDrivingCarPackage.COMMUNICATION_MODULE__DATA_TRANSFER_RATE:
				setDataTransferRate((Integer)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case SelfDrivingCarPackage.COMMUNICATION_MODULE__CONNECTION_TYPE:
				setConnectionType(CONNECTION_TYPE_EDEFAULT);
				return;
			case SelfDrivingCarPackage.COMMUNICATION_MODULE__DATA_TRANSFER_RATE:
				setDataTransferRate(DATA_TRANSFER_RATE_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case SelfDrivingCarPackage.COMMUNICATION_MODULE__CONNECTION_TYPE:
				return CONNECTION_TYPE_EDEFAULT == null ? connectionType != null : !CONNECTION_TYPE_EDEFAULT.equals(connectionType);
			case SelfDrivingCarPackage.COMMUNICATION_MODULE__DATA_TRANSFER_RATE:
				return dataTransferRate != DATA_TRANSFER_RATE_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eInvoke(int operationID, EList<?> arguments) throws InvocationTargetException {
		switch (operationID) {
			case SelfDrivingCarPackage.COMMUNICATION_MODULE___SEND_DATA:
				sendData();
				return null;
			case SelfDrivingCarPackage.COMMUNICATION_MODULE___RECEIVE_DATA:
				receiveData();
				return null;
		}
		return super.eInvoke(operationID, arguments);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (connectionType: ");
		result.append(connectionType);
		result.append(", dataTransferRate: ");
		result.append(dataTransferRate);
		result.append(')');
		return result.toString();
	}

} //CommunicationModuleImpl
