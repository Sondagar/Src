/**
 */
package SelfDrivingCar.impl;

import SelfDrivingCar.BrakeController;
import SelfDrivingCar.CameraSensor;
import SelfDrivingCar.CommunicationModule;
import SelfDrivingCar.ControlUnit;
import SelfDrivingCar.DriveSystem;
import SelfDrivingCar.LidarSensor;
import SelfDrivingCar.Location;
import SelfDrivingCar.MotorController;
import SelfDrivingCar.NavigationSystem;
import SelfDrivingCar.SelfDrivingCar;
import SelfDrivingCar.SelfDrivingCarFactory;
import SelfDrivingCar.SelfDrivingCarPackage;
import SelfDrivingCar.Sensor;
import SelfDrivingCar.SensorData;
import SelfDrivingCar.SteeringController;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EOperation;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

import org.eclipse.emf.ecore.impl.EPackageImpl;

import org.eclipse.uml2.types.TypesPackage;

import org.eclipse.uml2.types.impl.TypesPackageImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class SelfDrivingCarPackageImpl extends EPackageImpl implements SelfDrivingCarPackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass selfDrivingCarEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass locationEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass driveSystemEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass motorControllerEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass brakeControllerEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass steeringControllerEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass sensorEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass sensorDataEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass cameraSensorEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass lidarSensorEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass navigationSystemEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass controlUnitEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass communicationModuleEClass = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see SelfDrivingCar.SelfDrivingCarPackage#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private SelfDrivingCarPackageImpl() {
		super(eNS_URI, SelfDrivingCarFactory.eINSTANCE);
	}
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this model, and for any others upon which it depends.
	 *
	 * <p>This method is used to initialize {@link SelfDrivingCarPackage#eINSTANCE} when that field is accessed.
	 * Clients should not invoke it directly. Instead, they should simply access that field to obtain the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static SelfDrivingCarPackage init() {
		if (isInited) return (SelfDrivingCarPackage)EPackage.Registry.INSTANCE.getEPackage(SelfDrivingCarPackage.eNS_URI);

		// Obtain or create and register package
		Object registeredSelfDrivingCarPackage = EPackage.Registry.INSTANCE.get(eNS_URI);
		SelfDrivingCarPackageImpl theSelfDrivingCarPackage = registeredSelfDrivingCarPackage instanceof SelfDrivingCarPackageImpl ? (SelfDrivingCarPackageImpl)registeredSelfDrivingCarPackage : new SelfDrivingCarPackageImpl();

		isInited = true;

		// Obtain or create and register interdependencies
		Object registeredPackage = EPackage.Registry.INSTANCE.getEPackage(TypesPackage.eNS_URI);
		TypesPackageImpl theTypesPackage = (TypesPackageImpl)(registeredPackage instanceof TypesPackageImpl ? registeredPackage : TypesPackage.eINSTANCE);

		// Create package meta-data objects
		theSelfDrivingCarPackage.createPackageContents();
		theTypesPackage.createPackageContents();

		// Initialize created meta-data
		theSelfDrivingCarPackage.initializePackageContents();
		theTypesPackage.initializePackageContents();

		// Mark meta-data to indicate it can't be changed
		theSelfDrivingCarPackage.freeze();

		// Update the registry and return the package
		EPackage.Registry.INSTANCE.put(SelfDrivingCarPackage.eNS_URI, theSelfDrivingCarPackage);
		return theSelfDrivingCarPackage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getSelfDrivingCar() {
		return selfDrivingCarEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getSelfDrivingCar_Name() {
		return (EAttribute)selfDrivingCarEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EOperation getSelfDrivingCar__Start() {
		return selfDrivingCarEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EOperation getSelfDrivingCar__Stop() {
		return selfDrivingCarEClass.getEOperations().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EOperation getSelfDrivingCar__NavigateTo__Location() {
		return selfDrivingCarEClass.getEOperations().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EOperation getSelfDrivingCar__UpdateSensors() {
		return selfDrivingCarEClass.getEOperations().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EOperation getSelfDrivingCar__ProcessSensorData() {
		return selfDrivingCarEClass.getEOperations().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EOperation getSelfDrivingCar__MakeDecision() {
		return selfDrivingCarEClass.getEOperations().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EOperation getSelfDrivingCar__CommunicateWithCentralSystem() {
		return selfDrivingCarEClass.getEOperations().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EOperation getSelfDrivingCar__ExecuteDriveCommand() {
		return selfDrivingCarEClass.getEOperations().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getLocation() {
		return locationEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getLocation_Latitude() {
		return (EAttribute)locationEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getLocation_Longitude() {
		return (EAttribute)locationEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EOperation getLocation__GetDetails() {
		return locationEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getDriveSystem() {
		return driveSystemEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getDriveSystem_MotorController() {
		return (EReference)driveSystemEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getDriveSystem_BrakeController() {
		return (EReference)driveSystemEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getDriveSystem_SteeringController() {
		return (EReference)driveSystemEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EOperation getDriveSystem__Accelerate__float() {
		return driveSystemEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EOperation getDriveSystem__Brake() {
		return driveSystemEClass.getEOperations().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EOperation getDriveSystem__Steer__float() {
		return driveSystemEClass.getEOperations().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getMotorController() {
		return motorControllerEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getMotorController_MotorTemperature() {
		return (EAttribute)motorControllerEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EOperation getMotorController__SetSpeed__float() {
		return motorControllerEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getBrakeController() {
		return brakeControllerEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getBrakeController_BrakeTemperature() {
		return (EAttribute)brakeControllerEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EOperation getBrakeController__ApplyBrakes() {
		return brakeControllerEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getSteeringController() {
		return steeringControllerEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getSteeringController_SteeringMode() {
		return (EAttribute)steeringControllerEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EOperation getSteeringController__SetSteeringAngle__float() {
		return steeringControllerEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getSensor() {
		return sensorEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getSensor_Type() {
		return (EAttribute)sensorEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EOperation getSensor__GetData() {
		return sensorEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getSensorData() {
		return sensorDataEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getSensorData_Type() {
		return (EAttribute)sensorDataEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getSensorData_Data() {
		return (EAttribute)sensorDataEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EOperation getSensorData__GetDataType() {
		return sensorDataEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getCameraSensor() {
		return cameraSensorEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getCameraSensor_CameraType() {
		return (EAttribute)cameraSensorEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EOperation getCameraSensor__CaptureImage() {
		return cameraSensorEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getLidarSensor() {
		return lidarSensorEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getLidarSensor_LidarType() {
		return (EAttribute)lidarSensorEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EOperation getLidarSensor__ScanEnvironment() {
		return lidarSensorEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getNavigationSystem() {
		return navigationSystemEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getNavigationSystem_Map() {
		return (EAttribute)navigationSystemEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EOperation getNavigationSystem__CalculateRoute() {
		return navigationSystemEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getControlUnit() {
		return controlUnitEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getControlUnit_ProcessingPower() {
		return (EAttribute)controlUnitEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EOperation getControlUnit__ProcessInput() {
		return controlUnitEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getCommunicationModule() {
		return communicationModuleEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getCommunicationModule_ConnectionType() {
		return (EAttribute)communicationModuleEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getCommunicationModule_DataTransferRate() {
		return (EAttribute)communicationModuleEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EOperation getCommunicationModule__SendData() {
		return communicationModuleEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EOperation getCommunicationModule__ReceiveData() {
		return communicationModuleEClass.getEOperations().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public SelfDrivingCarFactory getSelfDrivingCarFactory() {
		return (SelfDrivingCarFactory)getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated) return;
		isCreated = true;

		// Create classes and their features
		selfDrivingCarEClass = createEClass(SELF_DRIVING_CAR);
		createEAttribute(selfDrivingCarEClass, SELF_DRIVING_CAR__NAME);
		createEOperation(selfDrivingCarEClass, SELF_DRIVING_CAR___START);
		createEOperation(selfDrivingCarEClass, SELF_DRIVING_CAR___STOP);
		createEOperation(selfDrivingCarEClass, SELF_DRIVING_CAR___NAVIGATE_TO__LOCATION);
		createEOperation(selfDrivingCarEClass, SELF_DRIVING_CAR___UPDATE_SENSORS);
		createEOperation(selfDrivingCarEClass, SELF_DRIVING_CAR___PROCESS_SENSOR_DATA);
		createEOperation(selfDrivingCarEClass, SELF_DRIVING_CAR___MAKE_DECISION);
		createEOperation(selfDrivingCarEClass, SELF_DRIVING_CAR___COMMUNICATE_WITH_CENTRAL_SYSTEM);
		createEOperation(selfDrivingCarEClass, SELF_DRIVING_CAR___EXECUTE_DRIVE_COMMAND);

		locationEClass = createEClass(LOCATION);
		createEAttribute(locationEClass, LOCATION__LATITUDE);
		createEAttribute(locationEClass, LOCATION__LONGITUDE);
		createEOperation(locationEClass, LOCATION___GET_DETAILS);

		driveSystemEClass = createEClass(DRIVE_SYSTEM);
		createEReference(driveSystemEClass, DRIVE_SYSTEM__MOTOR_CONTROLLER);
		createEReference(driveSystemEClass, DRIVE_SYSTEM__BRAKE_CONTROLLER);
		createEReference(driveSystemEClass, DRIVE_SYSTEM__STEERING_CONTROLLER);
		createEOperation(driveSystemEClass, DRIVE_SYSTEM___ACCELERATE__FLOAT);
		createEOperation(driveSystemEClass, DRIVE_SYSTEM___BRAKE);
		createEOperation(driveSystemEClass, DRIVE_SYSTEM___STEER__FLOAT);

		motorControllerEClass = createEClass(MOTOR_CONTROLLER);
		createEAttribute(motorControllerEClass, MOTOR_CONTROLLER__MOTOR_TEMPERATURE);
		createEOperation(motorControllerEClass, MOTOR_CONTROLLER___SET_SPEED__FLOAT);

		brakeControllerEClass = createEClass(BRAKE_CONTROLLER);
		createEAttribute(brakeControllerEClass, BRAKE_CONTROLLER__BRAKE_TEMPERATURE);
		createEOperation(brakeControllerEClass, BRAKE_CONTROLLER___APPLY_BRAKES);

		steeringControllerEClass = createEClass(STEERING_CONTROLLER);
		createEAttribute(steeringControllerEClass, STEERING_CONTROLLER__STEERING_MODE);
		createEOperation(steeringControllerEClass, STEERING_CONTROLLER___SET_STEERING_ANGLE__FLOAT);

		sensorEClass = createEClass(SENSOR);
		createEAttribute(sensorEClass, SENSOR__TYPE);
		createEOperation(sensorEClass, SENSOR___GET_DATA);

		sensorDataEClass = createEClass(SENSOR_DATA);
		createEAttribute(sensorDataEClass, SENSOR_DATA__TYPE);
		createEAttribute(sensorDataEClass, SENSOR_DATA__DATA);
		createEOperation(sensorDataEClass, SENSOR_DATA___GET_DATA_TYPE);

		cameraSensorEClass = createEClass(CAMERA_SENSOR);
		createEAttribute(cameraSensorEClass, CAMERA_SENSOR__CAMERA_TYPE);
		createEOperation(cameraSensorEClass, CAMERA_SENSOR___CAPTURE_IMAGE);

		lidarSensorEClass = createEClass(LIDAR_SENSOR);
		createEAttribute(lidarSensorEClass, LIDAR_SENSOR__LIDAR_TYPE);
		createEOperation(lidarSensorEClass, LIDAR_SENSOR___SCAN_ENVIRONMENT);

		navigationSystemEClass = createEClass(NAVIGATION_SYSTEM);
		createEAttribute(navigationSystemEClass, NAVIGATION_SYSTEM__MAP);
		createEOperation(navigationSystemEClass, NAVIGATION_SYSTEM___CALCULATE_ROUTE);

		controlUnitEClass = createEClass(CONTROL_UNIT);
		createEAttribute(controlUnitEClass, CONTROL_UNIT__PROCESSING_POWER);
		createEOperation(controlUnitEClass, CONTROL_UNIT___PROCESS_INPUT);

		communicationModuleEClass = createEClass(COMMUNICATION_MODULE);
		createEAttribute(communicationModuleEClass, COMMUNICATION_MODULE__CONNECTION_TYPE);
		createEAttribute(communicationModuleEClass, COMMUNICATION_MODULE__DATA_TRANSFER_RATE);
		createEOperation(communicationModuleEClass, COMMUNICATION_MODULE___SEND_DATA);
		createEOperation(communicationModuleEClass, COMMUNICATION_MODULE___RECEIVE_DATA);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized) return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Obtain other dependent packages
		TypesPackage theTypesPackage = (TypesPackage)EPackage.Registry.INSTANCE.getEPackage(TypesPackage.eNS_URI);

		// Create type parameters

		// Set bounds for type parameters

		// Add supertypes to classes
		cameraSensorEClass.getESuperTypes().add(this.getSensor());

		// Initialize classes, features, and operations; add parameters
		initEClass(selfDrivingCarEClass, SelfDrivingCar.class, "SelfDrivingCar", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getSelfDrivingCar_Name(), theTypesPackage.getString(), "name", null, 1, 1, SelfDrivingCar.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);

		initEOperation(getSelfDrivingCar__Start(), null, "start", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getSelfDrivingCar__Stop(), null, "stop", 1, 1, IS_UNIQUE, !IS_ORDERED);

		EOperation op = initEOperation(getSelfDrivingCar__NavigateTo__Location(), null, "navigateTo", 1, 1, IS_UNIQUE, !IS_ORDERED);
		addEParameter(op, this.getLocation(), "destination", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getSelfDrivingCar__UpdateSensors(), null, "updateSensors", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getSelfDrivingCar__ProcessSensorData(), null, "processSensorData", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getSelfDrivingCar__MakeDecision(), null, "makeDecision", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getSelfDrivingCar__CommunicateWithCentralSystem(), null, "communicateWithCentralSystem", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getSelfDrivingCar__ExecuteDriveCommand(), null, "executeDriveCommand", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEClass(locationEClass, Location.class, "Location", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getLocation_Latitude(), ecorePackage.getEFloat(), "latitude", null, 1, 1, Location.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getLocation_Longitude(), ecorePackage.getEFloat(), "longitude", null, 1, 1, Location.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);

		initEOperation(getLocation__GetDetails(), null, "getDetails", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEClass(driveSystemEClass, DriveSystem.class, "DriveSystem", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getDriveSystem_MotorController(), this.getMotorController(), null, "motorController", null, 1, 1, DriveSystem.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getDriveSystem_BrakeController(), this.getBrakeController(), null, "brakeController", null, 1, 1, DriveSystem.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEReference(getDriveSystem_SteeringController(), this.getSteeringController(), null, "steeringController", null, 1, 1, DriveSystem.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);

		op = initEOperation(getDriveSystem__Accelerate__float(), null, "accelerate", 1, 1, IS_UNIQUE, !IS_ORDERED);
		addEParameter(op, ecorePackage.getEFloat(), "speed", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getDriveSystem__Brake(), null, "brake", 1, 1, IS_UNIQUE, !IS_ORDERED);

		op = initEOperation(getDriveSystem__Steer__float(), null, "steer", 1, 1, IS_UNIQUE, !IS_ORDERED);
		addEParameter(op, ecorePackage.getEFloat(), "angle", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEClass(motorControllerEClass, MotorController.class, "MotorController", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getMotorController_MotorTemperature(), ecorePackage.getEFloat(), "motorTemperature", null, 1, 1, MotorController.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);

		op = initEOperation(getMotorController__SetSpeed__float(), null, "setSpeed", 1, 1, IS_UNIQUE, !IS_ORDERED);
		addEParameter(op, ecorePackage.getEFloat(), "speed", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEClass(brakeControllerEClass, BrakeController.class, "BrakeController", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getBrakeController_BrakeTemperature(), ecorePackage.getEFloat(), "brakeTemperature", null, 1, 1, BrakeController.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);

		initEOperation(getBrakeController__ApplyBrakes(), null, "applyBrakes", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEClass(steeringControllerEClass, SteeringController.class, "SteeringController", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getSteeringController_SteeringMode(), theTypesPackage.getString(), "steeringMode", null, 1, 1, SteeringController.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);

		op = initEOperation(getSteeringController__SetSteeringAngle__float(), null, "setSteeringAngle", 1, 1, IS_UNIQUE, !IS_ORDERED);
		addEParameter(op, ecorePackage.getEFloat(), "angle", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEClass(sensorEClass, Sensor.class, "Sensor", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getSensor_Type(), theTypesPackage.getString(), "type", null, 1, 1, Sensor.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);

		initEOperation(getSensor__GetData(), null, "getData", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEClass(sensorDataEClass, SensorData.class, "SensorData", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getSensorData_Type(), theTypesPackage.getString(), "type", null, 1, 1, SensorData.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getSensorData_Data(), ecorePackage.getEFloat(), "data", null, 1, 1, SensorData.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);

		initEOperation(getSensorData__GetDataType(), null, "getDataType", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEClass(cameraSensorEClass, CameraSensor.class, "CameraSensor", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getCameraSensor_CameraType(), theTypesPackage.getString(), "cameraType", null, 1, 1, CameraSensor.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);

		initEOperation(getCameraSensor__CaptureImage(), null, "captureImage", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEClass(lidarSensorEClass, LidarSensor.class, "LidarSensor", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getLidarSensor_LidarType(), theTypesPackage.getString(), "lidarType", null, 1, 1, LidarSensor.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);

		initEOperation(getLidarSensor__ScanEnvironment(), null, "scanEnvironment", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEClass(navigationSystemEClass, NavigationSystem.class, "NavigationSystem", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getNavigationSystem_Map(), ecorePackage.getEJavaObject(), "map", null, 1, 1, NavigationSystem.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);

		initEOperation(getNavigationSystem__CalculateRoute(), null, "calculateRoute", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEClass(controlUnitEClass, ControlUnit.class, "ControlUnit", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getControlUnit_ProcessingPower(), ecorePackage.getEFloat(), "processingPower", null, 1, 1, ControlUnit.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);

		initEOperation(getControlUnit__ProcessInput(), null, "processInput", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEClass(communicationModuleEClass, CommunicationModule.class, "CommunicationModule", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getCommunicationModule_ConnectionType(), theTypesPackage.getString(), "connectionType", null, 1, 1, CommunicationModule.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);
		initEAttribute(getCommunicationModule_DataTransferRate(), theTypesPackage.getInteger(), "dataTransferRate", null, 1, 1, CommunicationModule.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, !IS_ORDERED);

		initEOperation(getCommunicationModule__SendData(), null, "sendData", 1, 1, IS_UNIQUE, !IS_ORDERED);

		initEOperation(getCommunicationModule__ReceiveData(), null, "receiveData", 1, 1, IS_UNIQUE, !IS_ORDERED);

		// Create resource
		createResource(eNS_URI);
	}

} //SelfDrivingCarPackageImpl
