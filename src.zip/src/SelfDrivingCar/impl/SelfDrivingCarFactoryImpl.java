/**
 */
package SelfDrivingCar.impl;

import SelfDrivingCar.*;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class SelfDrivingCarFactoryImpl extends EFactoryImpl implements SelfDrivingCarFactory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static SelfDrivingCarFactory init() {
		try {
			SelfDrivingCarFactory theSelfDrivingCarFactory = (SelfDrivingCarFactory)EPackage.Registry.INSTANCE.getEFactory(SelfDrivingCarPackage.eNS_URI);
			if (theSelfDrivingCarFactory != null) {
				return theSelfDrivingCarFactory;
			}
		}
		catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new SelfDrivingCarFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SelfDrivingCarFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
			case SelfDrivingCarPackage.SELF_DRIVING_CAR: return createSelfDrivingCar();
			case SelfDrivingCarPackage.LOCATION: return createLocation();
			case SelfDrivingCarPackage.DRIVE_SYSTEM: return createDriveSystem();
			case SelfDrivingCarPackage.MOTOR_CONTROLLER: return createMotorController();
			case SelfDrivingCarPackage.BRAKE_CONTROLLER: return createBrakeController();
			case SelfDrivingCarPackage.STEERING_CONTROLLER: return createSteeringController();
			case SelfDrivingCarPackage.SENSOR: return createSensor();
			case SelfDrivingCarPackage.SENSOR_DATA: return createSensorData();
			case SelfDrivingCarPackage.CAMERA_SENSOR: return createCameraSensor();
			case SelfDrivingCarPackage.LIDAR_SENSOR: return createLidarSensor();
			case SelfDrivingCarPackage.NAVIGATION_SYSTEM: return createNavigationSystem();
			case SelfDrivingCarPackage.CONTROL_UNIT: return createControlUnit();
			case SelfDrivingCarPackage.COMMUNICATION_MODULE: return createCommunicationModule();
			default:
				throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public SelfDrivingCar createSelfDrivingCar() {
		SelfDrivingCarImpl selfDrivingCar = new SelfDrivingCarImpl();
		return selfDrivingCar;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Location createLocation() {
		LocationImpl location = new LocationImpl();
		return location;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public DriveSystem createDriveSystem() {
		DriveSystemImpl driveSystem = new DriveSystemImpl();
		return driveSystem;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public MotorController createMotorController() {
		MotorControllerImpl motorController = new MotorControllerImpl();
		return motorController;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public BrakeController createBrakeController() {
		BrakeControllerImpl brakeController = new BrakeControllerImpl();
		return brakeController;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public SteeringController createSteeringController() {
		SteeringControllerImpl steeringController = new SteeringControllerImpl();
		return steeringController;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Sensor createSensor() {
		SensorImpl sensor = new SensorImpl();
		return sensor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public SensorData createSensorData() {
		SensorDataImpl sensorData = new SensorDataImpl();
		return sensorData;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public CameraSensor createCameraSensor() {
		CameraSensorImpl cameraSensor = new CameraSensorImpl();
		return cameraSensor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public LidarSensor createLidarSensor() {
		LidarSensorImpl lidarSensor = new LidarSensorImpl();
		return lidarSensor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NavigationSystem createNavigationSystem() {
		NavigationSystemImpl navigationSystem = new NavigationSystemImpl();
		return navigationSystem;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ControlUnit createControlUnit() {
		ControlUnitImpl controlUnit = new ControlUnitImpl();
		return controlUnit;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public CommunicationModule createCommunicationModule() {
		CommunicationModuleImpl communicationModule = new CommunicationModuleImpl();
		return communicationModule;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public SelfDrivingCarPackage getSelfDrivingCarPackage() {
		return (SelfDrivingCarPackage)getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static SelfDrivingCarPackage getPackage() {
		return SelfDrivingCarPackage.eINSTANCE;
	}

} //SelfDrivingCarFactoryImpl
