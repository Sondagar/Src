/**
 */
package SelfDrivingCar;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Communication Module</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link SelfDrivingCar.CommunicationModule#getConnectionType <em>Connection Type</em>}</li>
 *   <li>{@link SelfDrivingCar.CommunicationModule#getDataTransferRate <em>Data Transfer Rate</em>}</li>
 * </ul>
 *
 * @see SelfDrivingCar.SelfDrivingCarPackage#getCommunicationModule()
 * @model
 * @generated
 */
public interface CommunicationModule extends EObject {
	/**
	 * Returns the value of the '<em><b>Connection Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Connection Type</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Connection Type</em>' attribute.
	 * @see #setConnectionType(String)
	 * @see SelfDrivingCar.SelfDrivingCarPackage#getCommunicationModule_ConnectionType()
	 * @model dataType="org.eclipse.uml2.types.String" required="true" ordered="false"
	 * @generated
	 */
	String getConnectionType();

	/**
	 * Sets the value of the '{@link SelfDrivingCar.CommunicationModule#getConnectionType <em>Connection Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Connection Type</em>' attribute.
	 * @see #getConnectionType()
	 * @generated
	 */
	void setConnectionType(String value);

	/**
	 * Returns the value of the '<em><b>Data Transfer Rate</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Data Transfer Rate</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Data Transfer Rate</em>' attribute.
	 * @see #setDataTransferRate(int)
	 * @see SelfDrivingCar.SelfDrivingCarPackage#getCommunicationModule_DataTransferRate()
	 * @model dataType="org.eclipse.uml2.types.Integer" required="true" ordered="false"
	 * @generated
	 */
	int getDataTransferRate();

	/**
	 * Sets the value of the '{@link SelfDrivingCar.CommunicationModule#getDataTransferRate <em>Data Transfer Rate</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Data Transfer Rate</em>' attribute.
	 * @see #getDataTransferRate()
	 * @generated
	 */
	void setDataTransferRate(int value);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void sendData();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void receiveData();

} // CommunicationModule
